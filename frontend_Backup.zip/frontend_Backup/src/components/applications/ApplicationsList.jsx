import { useState, useCallback } from 'react'
import StatusBadge from '../common/StatusBadge'
import CalendarTiles from '../common/CalendarTiles'
import { formatDate } from '../../utils/format'
import './ApplicationsList.css'

const formatStatusClass = (status) =>
  status ? `app-card--status-${String(status).toLowerCase()}` : ''

const canCancel = (status) => status === 'PENDING_APPROVAL' || status === 'APPROVED'

const isDateEditable = (dateStatus) => dateStatus === 'BOOKED'

export default function ApplicationsList({ apps, cancelApplication, cancelBookingDates }) {
  if (!apps.length) {
    return <p>No applications match these filters.</p>
  }

  return (
    <div className="app-list">
      {apps.map((application) => {
        const bookingDates = application.booking_dates || []
        const cancellableDates = bookingDates.filter((date) => isDateEditable(date.status))
        const hasSelectableDates = cancellableDates.length > 1

        return (
          <div
            key={application.id}
            className={`card app-card ${formatStatusClass(application.status)}`}
          >
            <div className="app-card__head">
              <div>
                <span className="app-card__application-number">
                  {application.application_number}
                </span>
                <div className="app-card__meta">
                  {application.route?.route_number && <span>Route {application.route.route_number}</span>}
                  {application.bus?.bus_number && <span>Bus {application.bus.bus_number}</span>}
                  {application.shift?.shift_name && <span>{application.shift.shift_name}</span>}
                </div>
              </div>
              <StatusBadge status={application.status} size="md" />
            </div>

            <div className="app-card__dates-section">
              <div className="app-card__section-title">
                <span>Booking dates</span>
                <span className="app-card__section-count">
                  {bookingDates.length} total
                </span>
              </div>
              <CalendarTiles
                dates={bookingDates}
                passValidFrom={application.pass_valid_from}
                passValidTo={application.pass_valid_to}
                maxMonths={2}
              />
            </div>

            {hasSelectableDates && (
              <div className="app-card__dates-section">
                <div className="app-card__section-title">
                  <span>Select dates to cancel</span>
                  <span className="app-card__section-count">
                    {cancellableDates.length} editable
                  </span>
                </div>
                <BookingDatesTable
                  application={application}
                  bookingDates={bookingDates}
                  cancellableDates={cancellableDates}
                  onCancelDates={cancelBookingDates}
                />
              </div>
            )}

            {canCancel(application.status) && (
              <div className="app-card__actions">
                <button
                  type="button"
                  className="app-cancel"
                  onClick={() => cancelApplication?.(application.id)}
                >
                  Cancel full booking
                </button>
              </div>
            )}

            {application.rejection_reason && (
              <div className="app-table__reason">{application.rejection_reason}</div>
            )}
          </div>
        )
      })}
    </div>
  )
}

function BookingDatesTable({ application, bookingDates, cancellableDates, onCancelDates }) {
  const [selectedIds, setSelectedIds] = useState([])
  const [isOpen, setIsOpen] = useState(false)

  const toggleSelection = (dateId) => {
    setSelectedIds((current) =>
      current.includes(dateId)
        ? current.filter((id) => id !== dateId)
        : [...current, dateId]
    )
  }

  const selectAll = () => {
    setSelectedIds(cancellableDates.map((date) => date.id))
  }

  const clearSelection = () => {
    setSelectedIds([])
  }

  const handleCancelSelected = async () => {
    if (!selectedIds.length) return
    const confirmed = window.confirm(
      `Are you sure you want to cancel ${selectedIds.length} date${selectedIds.length > 1 ? 's' : ''}? This action cannot be undone.`
    )
    if (!confirmed) return
    await onCancelDates?.(application.id, selectedIds)
    setSelectedIds([])
  }

  const allSelected = cancellableDates.length > 1 && selectedIds.length === cancellableDates.length
  const someSelected = selectedIds.length > 0 && !allSelected

  if (!isOpen) {
    return (
      <button type="button" className="booking-dates-toggle" onClick={() => setIsOpen(true)}>
        <span>Select and cancel dates</span>
        <span className="booking-dates-toggle__arrow">▾</span>
      </button>
    )
  }

  return (
    <div className="booking-dates-table">
      <div className="booking-dates-table__header">
        <div>
          <b>Booking dates</b>
          <span className="booking-dates-table__count">
            {bookingDates.length} total, {cancellableDates.length} editable
          </span>
        </div>
        <div className="booking-dates-table__selection-controls">
          <button type="button" onClick={allSelected ? clearSelection : selectAll}>
            {allSelected ? 'Clear selection' : 'Select all'}
          </button>
          {selectedIds.length > 0 && (
            <button type="button" className="booking-dates-table__cancel-selected" onClick={handleCancelSelected}>
              Cancel {selectedIds.length} date{selectedIds.length > 1 ? 's' : ''}
            </button>
          )}
          <button type="button" className="booking-dates-toggle booking-dates-toggle--ghost" onClick={() => { setIsOpen(false); clearSelection() }}>
            Collapse
          </button>
        </div>
      </div>

      <div className="booking-dates-table__list">
        {bookingDates.map((date) => {
          const isCancelled = date.status === 'CANCELLED'
          const isSelected = selectedIds.includes(date.id)
          const isDisabled = isCancelled || !isDateEditable(date.status)
          const dateObj = new Date(date.booking_date + 'T00:00:00')

          return (
            <div
              key={date.id}
              className={`booking-dates-table__item ${isSelected ? 'booking-dates-table__item--selected' : ''} ${isCancelled ? 'booking-dates-table__item--cancelled' : ''}`}
            >
              <label className="booking-dates-table__label">
                <input
                  type="checkbox"
                  checked={isSelected}
                  disabled={isDisabled}
                  onChange={() => toggleSelection(date.id)}
                />
                <span className="booking-dates-table__checkbox" />
              </label>

              <div className="booking-dates-table__info">
                <span className="booking-dates-table__date">{formatDate(date.booking_date)}</span>
                <span className="booking-dates-table__day">{dateObj.toLocaleDateString('en-IN', { weekday: 'short' })}</span>
              </div>

              <div className="booking-dates-table__status">
                <StatusBadge status={isCancelled ? 'CANCELLED' : 'BOOKED'} size="sm" />
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
