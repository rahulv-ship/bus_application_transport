import { useEffect } from 'react'
import Button from './Button'
import './Modal.css'

export default function Modal({ open, title, message, confirmLabel = 'OK', onConfirm }) {
  useEffect(() => {
    if (!open) return
    const handler = (event) => {
      if (event.key === 'Escape') onConfirm?.()
    }
    document.addEventListener('keydown', handler)
    return () => document.removeEventListener('keydown', handler)
  }, [open, onConfirm])

  if (!open) return null

  return (
    <div className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
      <div className="modal__backdrop" onClick={onConfirm} />
      <div className="modal__panel">
        <div className="modal__header">
          <h3 id="modal-title">{title}</h3>
        </div>
        <div className="modal__body">
          <p>{message}</p>
        </div>
        <div className="modal__footer">
          <Button variant="primary" onClick={onConfirm}>{confirmLabel}</Button>
        </div>
      </div>
    </div>
  )
}
