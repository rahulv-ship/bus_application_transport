import { CheckCircle2, XCircle } from 'lucide-react'
import Notice from '../../components/common/Notice'
import { SkeletonCard } from '../../components/common/Skeleton'
import Button from '../../components/common/Button'
import { useAdminApprovals } from '../../hooks/useAdminApprovals'
import CalendarTiles from '../../components/common/CalendarTiles'
import './ApprovalsPage.css'

export default function ApprovalsPage() {
  const { apps, notice, loading, loadingList, act } = useAdminApprovals()

  const handleReject = (id) => {
    const reason = window.prompt('Rejection reason:')
    if (!reason) return
    act(id, 'reject', reason)
  }

  return (
    <div className="stack">
      <h1>Bus Pass Approvals</h1>

      {notice && <Notice>{notice}</Notice>}

      <div className="card">
        {loadingList && <SkeletonCard lines={5} />}

        {!loadingList && !apps.length && <p>No pending applications.</p>}

        {!loadingList && apps.length > 0 && (
          <table className="approvals-table">
            <thead>
              <tr>
                <th>Application</th>
                <th>Employee</th>
                <th>Department</th>
                <th>Route</th>
                <th>Bus</th>
                <th>Stops</th>
                <th>Dates</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {apps.map((application) => (
                <tr key={application.id}>
                  <td className="font-mono">{application.application_number}</td>
                  <td>
                    <div>{application.employee?.employee_name}</div>
                    <div className="approvals-table__sub">{application.employee?.employee_code}</div>
                  </td>
                  <td>{application.employee?.department}</td>
                  <td>{application.route?.route_number}</td>
                  <td>{application.bus?.bus_number}</td>
                  <td>
                    {application.pickupStop?.stop_name} → {application.dropStop?.stop_name}
                  </td>
                  <td>
                    <CalendarTiles
                      dates={application.booking_dates || []}
                      passValidFrom={application.pass_valid_from}
                      passValidTo={application.pass_valid_to}
                      maxMonths={3}
                    />
                  </td>
                  <td>
                    <div className="cluster">
                      <Button
                        variant="secondary"
                        size="sm"
                        icon={CheckCircle2}
                        disabled={loading}
                        onClick={() => act(application.id, 'approve')}
                      >
                        Approve
                      </Button>
                      <Button
                        variant="danger"
                        size="sm"
                        icon={XCircle}
                        disabled={loading}
                        onClick={() => handleReject(application.id)}
                      >
                        Reject
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
