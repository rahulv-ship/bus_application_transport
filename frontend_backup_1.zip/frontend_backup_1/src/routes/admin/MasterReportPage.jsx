import { useEffect, useState } from 'react'
import api from '../../services/api'
import Button from '../../components/common/Button'
import AlertModal from '../../components/common/AlertModal'

export default function MasterReportPage() {
  const [r, setR] = useState(null)
  const [e, setE] = useState('')
  const [showError, setShowError] = useState(false)

  useEffect(() => {
    api.get('/admin/master-report')
      .then(x => setR(x.data.data))
      .catch(x => {
        setE(x.response?.data?.message || x.message)
        setShowError(true)
      })
  }, [])

  useEffect(() => {
    if (e) setShowError(true)
  }, [e])

  const dl = () => {
    const lines = Object.entries(r).flatMap(([t, a]) =>
      a.map(x => `${t},${x.id},${x.bus_number || x.route_number || x.stop_name || x.shift_name || x.vendor_name || x.driver_name || x.conductor_name || ''},${x.status || ''}`)
    )
    const u = URL.createObjectURL(new Blob([`Type,ID,Name,Status\n${lines.join('\n')}`], { type: 'text/csv' }))
    const a = document.createElement('a')
    a.href = u
    a.download = 'bus-master-report.csv'
    a.click()
    URL.revokeObjectURL(u)
  }

  return (
    <div className="stack master-report-page">
      <div className="page-header">
        <div>
          <h1>Master Report</h1>
          <p className="page-subtitle">Consolidated overview of all system master data.</p>
        </div>
        {r && (
          <Button onClick={dl} className="btn-download">
            <svg className="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
            </svg>
            Download CSV
          </Button>
        )}
      </div>

      <AlertModal open={showError} title="Alert" message={e} confirmLabel="Close" onConfirm={() => setShowError(false)} />

      <section className="card">
        <h2>Consolidated Master Data</h2>
        
        {r ? (
          <>
            <div className="admin-stat-grid">
              {Object.entries(r).map(([k, v]) => (
                <article key={k} className="stat-card">
                  <b>{v.length}</b>
                  <span>{k.replace(/_/g, ' ')}</span>
                </article>
              ))}
            </div>
          </>
        ) : (
          <div className="loading-state">
            <div className="spinner"></div>
            <p>Preparing report…</p>
          </div>
        )}
      </section>
    </div>
  )
}